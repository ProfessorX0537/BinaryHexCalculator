package Calculator;
public abstract class Conversions {
    public int toDecimal(String type) {
        return 0;
    }
}
